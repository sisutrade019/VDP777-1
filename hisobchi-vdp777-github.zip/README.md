# HISOBCHI VDP777®
Складской учёт: приход, расход, склады с папками, отчёты, накладные A4. Все данные хранятся только на устройстве.
SISU TRADE® — trader of dreams

## Как выложить на GitHub Pages
1. Создайте репозиторий на github.com (New repository), например `hisobchi-vdp777`.
2. Нажмите **Add file → Upload files**, перетащите всё содержимое этого архива (index.html, manifest.json, sw.js, папку icons, .nojekyll) и нажмите **Commit changes**.
3. Откройте **Settings → Pages**, в Source выберите **Deploy from a branch**, ветка **main**, папка **/(root)**, нажмите Save.
4. Через 1–2 минуты приложение откроется по адресу `https://ВАШ-ЛОГИН.github.io/hisobchi-vdp777/`.
5. На телефоне откройте ссылку в Chrome → меню → **Добавить на главный экран**.

Вход по отпечатку работает только на https-странице (GitHub Pages подходит).
Данные не уходят на сервер. Делайте «Сохранить копию» в разделе «Копия данных».
